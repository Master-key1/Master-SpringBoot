package com.ashokit.exceptionhandlers;

public class NoCustomerException  extends RuntimeException {

	public NoCustomerException() {
		super();
	}
	
	public NoCustomerException(String msg) {
		super(msg);
	}

}
