package com.ashokit.exceptionhandlers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException.BadRequest;

import com.ashokit.exception.ApiError;

@RestControllerAdvice
public class GlobalExceptionsHandler {

	@ExceptionHandler(value = {ArithmeticException.class})
	public ResponseEntity<ApiError> handleArithmeticException(ArithmeticException ae){
		
		String expMsg = ae.getMessage();
		String expCode = "Exp01";
		
		ApiError api =  new ApiError();
		api.setCode(expCode);
		api.setMsg(expMsg);
		return new ResponseEntity<ApiError>(api,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(value = {NoCustomerException.class})
	public ResponseEntity<ApiError> handleNoCustomerFoundException(NoCustomerException ncfe){
		
		String expMsg = ncfe.getMessage();
		String expCode = "Exp0123";
		
		ApiError api =  new ApiError();
		api.setCode(expCode);
		api.setMsg(expMsg);
		return new ResponseEntity<ApiError>(api,HttpStatus.BAD_REQUEST);
	}
	
	
	@ExceptionHandler(value = {Exception.class})
	public ResponseEntity<ApiError> handleException(Exception ncfe){
		
		String expMsg = ncfe.getMessage();
		String expCode = "Exp0100";
		
		ApiError api =  new ApiError();
		api.setCode(expCode);
		api.setMsg(expMsg);
		return new ResponseEntity<ApiError>(api,HttpStatus.BAD_REQUEST);
	}
}
