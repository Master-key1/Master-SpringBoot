package com.ashokit.restcontroller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ashokit.exception.ApiError;

@RestController
public class MathController {

	@PostMapping(value = "/sum")
	public ResponseEntity<String> doSum(){
		
		int num1 = 10 + 20 ;
		
		return new ResponseEntity<String>("Result :"+ num1 , HttpStatus.ACCEPTED);
	}
	/*@PostMapping(value = "/div")  // this way will not display exception the to webclient 
	public ResponseEntity<String> doDiv(){
		int num1 = 0 ;
		try {
		 num1 = 100 / 0 ;
		}catch(ArithmeticException e) {
			e.printStackTrace();
		}
		
		return new ResponseEntity<String>("Result :"+ num1 , HttpStatus.ACCEPTED);
	}*/
	@PostMapping(value = "/div")
	public ResponseEntity<String> doDiv() {
		int num1 = 0;
		num1 = 100 / 0;
		return new ResponseEntity<String>("Result :" + num1, HttpStatus.ACCEPTED);
	}
	

	
}





















