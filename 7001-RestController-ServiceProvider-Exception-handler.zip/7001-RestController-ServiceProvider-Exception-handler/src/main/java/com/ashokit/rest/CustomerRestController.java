package com.ashokit.rest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ashokit.exceptionhandlers.NoCustomerException;

import jakarta.websocket.server.PathParam;

@RestController
public class CustomerRestController {
	
	@GetMapping("/customer/{cid}")
	public ResponseEntity<String> getCustomerEmail(@PathParam("cid") Integer custId){
		
		String email=null;
		if(custId == 100) {
			email ="school@gmail.com";
		}else {
			throw new NoCustomerException("Invalid Customer........!");
		}
		return new ResponseEntity<String>(email,HttpStatus.OK);
	}

}
