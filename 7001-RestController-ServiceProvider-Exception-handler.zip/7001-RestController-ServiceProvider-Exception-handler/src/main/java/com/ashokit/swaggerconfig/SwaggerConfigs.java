package com.ashokit.swaggerconfig;

import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;


import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfigs {

	/*
	 * @Bean public OpenAPI apiInfo() { return new OpenAPI() .info(new Info()
	 * .title("Ashokit API Documentation")
	 * .description("API documentation for Ashokit services") .version("1.0.0")); }
	 */
	
	@Bean
	public GroupedOpenApi publicApi() {
		return GroupedOpenApi.builder()
				.group("public-api")
				.packagesToScan("com.ashokit")
				.pathsToMatch("/**")
				.build();

	}
}