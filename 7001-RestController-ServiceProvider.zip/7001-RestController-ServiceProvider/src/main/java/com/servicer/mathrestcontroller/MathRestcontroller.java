package com.servicer.mathrestcontroller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.servicer.binding.Operators;

@RestController
@RequestMapping("/api")
public class MathRestcontroller {

    @PostMapping(
        value = "/cal",
        consumes = {"application/json", "application/xml"},
        produces = {"application/json", "application/xml"}
    )
    public ResponseEntity<Operators> getInput(@RequestBody Operators ops) {

        if (ops.getNum1() == null || ops.getNum2() == null || ops.getCh() == null) {
            return new ResponseEntity<>(ops, HttpStatus.BAD_REQUEST);
        }

        String ch = ops.getCh();
        Integer resp = null;
        int num1 = ops.getNum1();
        int num2 = ops.getNum2();

        switch (ch) {
            case "+":
                resp = num1 + num2;
                break;
            case "-":
                resp = num1 - num2;
                break;
            case "*":
                resp = num1 * num2;
                break;
            case "/":
                if (num2 == 0) {
                    return new ResponseEntity<>(ops, HttpStatus.BAD_REQUEST);
                }
                resp = num1 / num2;
                break;
            default:
                return new ResponseEntity<>(ops, HttpStatus.BAD_REQUEST);
        }

        ops.setResult(resp);
        return new ResponseEntity<>(ops, HttpStatus.OK);
    }
}
