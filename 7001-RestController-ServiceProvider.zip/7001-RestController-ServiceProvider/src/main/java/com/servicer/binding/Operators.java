package com.servicer.binding;

public class Operators {
	private Integer num1;
	private Integer num2;
	private String ch;
	
	
	
	
	public Operators(Integer num1, Integer num2, String ch) {
		super();
		this.num1 = num1;
		this.num2 = num2;
		this.ch = ch;
	}
	public Integer getNum1() {
		return num1;
	}
	public void setNum1(Integer num1) {
		this.num1 = num1;
	}
	public Integer getNum2() {
		return num2;
	}
	public void setNum2(Integer num2) {
		this.num2 = num2;
	}
	public String getCh() {
		return ch;
	}
	public void setCh(String ch) {
		this.ch = ch;
	}
	@Override
	public String toString() {
		return "Operators [num1=" + num1 + ", num2=" + num2 + ", ch=" + ch + "]";
	}
	public void setResult(Integer resp) {
		// TODO Auto-generated method stub
		
	}

	
}
