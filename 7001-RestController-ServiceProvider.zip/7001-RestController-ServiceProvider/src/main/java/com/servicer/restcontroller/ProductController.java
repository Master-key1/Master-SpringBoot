package com.servicer.restcontroller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.servicer.binding.Product;
import com.servicer.service.ProductServiceImp;

@RestController
@RequestMapping("/api/products") // ✅ Base path for all product endpoints
public class ProductController {

	@Autowired
	private ProductServiceImp productServiceImp;
	
	
	

	// ✅ Add Product
	@PostMapping(value = "/add", consumes = { "application/json", "application/xml" }, produces = {
			"application/json", "application/xml" })

	public ResponseEntity<String> addProduct(@RequestBody Product product) {
		if (product == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("⚠️ Please provide valid product data!");
		}

		boolean result = productServiceImp.addProduct(product);

		
		if (result) {
			return ResponseEntity.status(HttpStatus.CREATED)
					.body("✅ Product added successfully! " + product.toString());
		} else {
			// ❌ You returned null before — that’s not good practice.
			// ✅ Always return a valid ResponseEntity
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("❌ Failed to add product!");
		}
	}

	// ✅ Get Product by ID
	@GetMapping(value = "/{pid}")
	public ResponseEntity<Product> getProduct(@PathVariable("pid") String pid) {
		System.out.println("Pid:"+pid);
		Product product = productServiceImp.getProduct(pid);
		System.out.println("Product :"+product);
		if (product != null) {
			return new ResponseEntity<Product>(product, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	// ✅ Get All Products
	@GetMapping(value = "/list")
	public ResponseEntity<List<Product>> getProductList() {
		List<Product> productList = productServiceImp.getAllProduct();

		if (productList == null || productList.isEmpty()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		return new ResponseEntity<>(productList, HttpStatus.OK);
	}
}
