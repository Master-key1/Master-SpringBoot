package com.servicer.service;

import java.util.List;

import com.servicer.binding.Product;

public interface ProductService {
	
	public boolean addProduct(Product product);
	public Product getProduct(String  pid);
	public List<Product> getAllProduct();

}
