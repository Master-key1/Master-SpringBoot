package com.servicer.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Service;

import com.servicer.binding.Product;

@Service
public class ProductServiceImp implements ProductService {
	
	static List<Product>list = new ArrayList<>();
	Map<String, Product>map = new HashMap<>();
	

	public List<Product> getList() {
		return list;
	}

	public  ProductServiceImp(){
		   	list.add(new Product("101", "Mobile", "120.0"));
	    	list.add(new Product("102", "Pen", "10.5"));
	    	list.add(new Product("103", "Notebook", "25.75"));
	    	list.add(new Product("104", "Laptop", "999.99"));
	    	list.add(new Product("105", "Headphones", "55.45"));
	    	list.add(new Product("106", "Charger", "30.00"));
	    	list.add(new Product("107", "Mouse", "20.25"));
	    	list.add(new Product("108", "Keyboard", "45.50"));
	    	list.add(new Product("109", "Monitor", "150.10"));
	    	list.add(new Product("110", "Tablet", "300.0"));

	}

	@Override
	public  boolean addProduct(Product product) {
		
		return list.add(product);
		
	}

	@Override
	public Product getProduct( String pid) {
		// TODO Auto-generated method stub
		return list.stream()
		           .filter(e-> e.getProductId().equals(pid))
		           .findAny()
		           .orElse(null);
	}

	@Override
	public List<Product> getAllProduct() {
		return getList();
	}

}
