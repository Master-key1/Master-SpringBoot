package com.ashokit.binding;

public class Product {
	
	private Integer pid;
	private String Pname;
	private Integer price;
	
	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	public String getPname() {
		return Pname;
	}
	public void setPname(String pname) {
		Pname = pname;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer i) {
		this.price = i;
	}
	@Override
	public String toString() {
		return "Product [pid=" + pid + ", Pname=" + Pname + ", price=" + price + "]";
	}
	
	

}
