package com.ashokit.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ashokit.binding.Product;

@Controller
public class ProductController {
	
	// Option-01 Loading form using modelAmdView
	@GetMapping("/product1")
	public ModelAndView loadingform() {
			ModelAndView mav = new ModelAndView();
			mav.addObject("product",new Product());
			mav.setViewName("productView");
		return mav;
	}
	
	//OPtion-02 loading form using Model
	@GetMapping("/product")
	public String loadForm(Model model) {
		model.addAttribute("product", new Product());  // addeing data to model object map
		return "productView";  //returnig view name
	}
	
	@PostMapping("/submit")
	public  ModelAndView handleSubmitBtn(Product product) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("submittedProduct", product);
		mav.setViewName("Result");

		return mav;
		
	}

}
