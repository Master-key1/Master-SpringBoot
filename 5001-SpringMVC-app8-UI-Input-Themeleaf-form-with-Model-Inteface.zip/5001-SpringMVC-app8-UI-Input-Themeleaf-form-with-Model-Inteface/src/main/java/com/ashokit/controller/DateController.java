package com.ashokit.controller;

import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DateController {
	
	@GetMapping("/date")
	@ResponseBody  // thre is no concept of viewname body
	public String display() {
			
		LocalDate date = LocalDate.now();
		return "Today's date  is : "+date;
		
	}

}
